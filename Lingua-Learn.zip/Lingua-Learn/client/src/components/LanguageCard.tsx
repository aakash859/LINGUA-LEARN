import { motion } from "framer-motion";
import { Check } from "lucide-react";

interface LanguageCardProps {
  language: string;
  nativeName: string;
  color: string;
  isSelected?: boolean;
  onClick: () => void;
}

export function LanguageCard({ language, nativeName, color, isSelected, onClick }: LanguageCardProps) {
  return (
    <motion.button
      whileHover={{ y: -4, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`
        relative overflow-hidden w-full p-6 h-32 rounded-2xl text-left transition-all duration-300
        border-2 shadow-sm hover:shadow-lg
        ${isSelected 
          ? 'border-primary ring-4 ring-primary/10 shadow-xl' 
          : 'border-transparent bg-white hover:border-border'}
      `}
      style={{
        background: isSelected ? 'white' : undefined
      }}
    >
      {/* Decorative gradient blob */}
      <div 
        className={`absolute -right-4 -top-4 w-24 h-24 rounded-full opacity-10 blur-xl`} 
        style={{ backgroundColor: color }}
      />
      <div 
        className={`absolute -left-4 -bottom-4 w-20 h-20 rounded-full opacity-10 blur-xl`} 
        style={{ backgroundColor: color }}
      />

      <div className="relative z-10 flex flex-col justify-between h-full">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
            {language}
          </span>
          <h3 className="text-2xl font-bold mt-1 text-foreground" style={{ color: isSelected ? color : undefined }}>
            {nativeName}
          </h3>
        </div>

        {isSelected && (
          <motion.div 
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="absolute bottom-4 right-4 bg-primary text-white p-1.5 rounded-full"
          >
            <Check className="w-4 h-4" strokeWidth={3} />
          </motion.div>
        )}
      </div>
    </motion.button>
  );
}
