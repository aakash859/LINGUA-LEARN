import { ReactNode } from "react";
import { BookOpen } from "lucide-react";
import { Link } from "wouter";

interface LayoutProps {
  children: ReactNode;
  showBack?: boolean;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-slate-50 relative overflow-hidden flex flex-col">
      {/* Background decorations */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] rounded-full bg-blue-200/20 blur-3xl" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] rounded-full bg-purple-200/20 blur-3xl" />
        <div className="absolute top-[40%] left-[20%] w-[300px] h-[300px] rounded-full bg-pink-200/20 blur-3xl" />
      </div>

      <header className="relative z-10 w-full max-w-5xl mx-auto px-6 py-6 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
          <div className="bg-primary text-white p-2.5 rounded-xl shadow-lg shadow-primary/25">
            <BookOpen className="w-6 h-6" />
          </div>
          <span className="text-xl font-bold font-display text-slate-800">LearnMate</span>
        </Link>
      </header>

      <main className="relative z-10 flex-1 w-full max-w-3xl mx-auto px-6 pb-12 flex flex-col justify-center">
        {children}
      </main>
      
      <footer className="relative z-10 py-6 text-center text-slate-400 text-sm font-medium">
        <p>© 2024 LearnMate • AI Powered Learning</p>
      </footer>
    </div>
  );
}
