import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Layout } from "@/components/Layout";
import { useAskQuestion } from "@/hooks/use-questions";
import { Sparkles, Loader2, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AskQuestion() {
  const [location, setLocation] = useLocation();
  const [question, setQuestion] = useState("");
  const [language, setLanguage] = useState<string>("");
  const { toast } = useToast();
  
  const { mutate, isPending } = useAskQuestion();

  useEffect(() => {
    const storedLang = localStorage.getItem("selectedLanguage");
    if (!storedLang) {
      setLocation("/");
      return;
    }
    setLanguage(storedLang);
  }, [setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    mutate(
      { language, question },
      {
        onSuccess: (data) => {
          // Pass data to explanation page via localStorage since wouter state is tricky
          localStorage.setItem("lastExplanation", JSON.stringify(data));
          setLocation("/explanation");
        },
        onError: (error) => {
          toast({
            title: "Error",
            description: error.message,
            variant: "destructive",
          });
        },
      }
    );
  };

  return (
    <Layout>
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="w-full max-w-2xl mx-auto"
      >
        <button 
          onClick={() => setLocation("/")}
          className="mb-6 flex items-center gap-2 text-slate-400 hover:text-slate-600 font-medium transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Change Language</span>
        </button>

        <div className="bg-white rounded-3xl p-8 shadow-xl shadow-slate-200/50 border border-slate-100">
          <div className="flex items-center gap-3 mb-2">
             <span className="inline-block px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-xs font-bold uppercase tracking-wide">
              Step 2 of 3
            </span>
            <span className="text-sm font-medium text-slate-400">Selected: {language}</span>
          </div>
          
          <h1 className="text-3xl md:text-4xl font-extrabold text-slate-900 mb-6 font-display">
            What do you want to learn?
          </h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="relative">
              <textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder={`Type your question here...\nExample: Why is the sky blue?`}
                className="w-full h-48 p-6 rounded-2xl bg-slate-50 border-2 border-slate-200 text-lg text-slate-800 placeholder:text-slate-400 focus:border-primary focus:ring-4 focus:ring-primary/10 focus:outline-none transition-all resize-none"
                disabled={isPending}
              />
              <div className="absolute bottom-4 right-4 text-xs font-bold text-slate-400 bg-white px-2 py-1 rounded-lg border border-slate-100">
                AI Powered
              </div>
            </div>

            <button
              type="submit"
              disabled={!question.trim() || isPending}
              className={`
                w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-3
                transition-all duration-300 transform
                ${!question.trim() || isPending
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  : 'bg-primary text-white shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-1 active:translate-y-0'}
              `}
            >
              {isPending ? (
                <>
                  <Loader2 className="w-6 h-6 animate-spin" />
                  <span>Thinking...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-6 h-6" />
                  <span>Get Explanation</span>
                </>
              )}
            </button>
          </form>
        </div>
        
        <p className="text-center mt-6 text-slate-400 text-sm">
          Our AI tutor will explain the concept simply in {language}.
        </p>
      </motion.div>
    </Layout>
  );
}
