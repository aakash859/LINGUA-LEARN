import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Layout } from "@/components/Layout";
import { LanguageCard } from "@/components/LanguageCard";
import { ArrowRight } from "lucide-react";

const LANGUAGES = [
  { id: "Tamil", native: "தமிழ்", color: "#F43F5E" },
  { id: "Hindi", native: "हिन्दी", color: "#EA580C" },
  { id: "Telugu", native: "తెలుగు", color: "#059669" },
  { id: "Kannada", native: "ಕನ್ನಡ", color: "#D946EF" },
  { id: "Malayalam", native: "മലയാളം", color: "#0891B2" },
  { id: "English", native: "English", color: "#4F46E5" },
];

export default function LanguageSelection() {
  const [, setLocation] = useLocation();
  const [selectedLang, setSelectedLang] = useState<string | null>(null);

  const handleContinue = () => {
    if (selectedLang) {
      // Store in localStorage for persistence across reloads if needed, 
      // but for this flow we'll just pass it via URL or simple state if using context.
      // Since wouter doesn't support state passing easily without context, 
      // we'll use a query param or just simple localStorage for simplicity.
      localStorage.setItem("selectedLanguage", selectedLang);
      setLocation("/ask");
    }
  };

  return (
    <Layout>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-8"
      >
        <div className="text-center space-y-3">
          <span className="inline-block px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-sm font-bold uppercase tracking-wide">
            Step 1 of 3
          </span>
          <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 leading-tight">
            Choose your language
          </h1>
          <p className="text-lg text-slate-500 max-w-md mx-auto">
            Select the language you want to learn in. We'll provide explanations in this language.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {LANGUAGES.map((lang, index) => (
            <motion.div
              key={lang.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <LanguageCard
                language={lang.id}
                nativeName={lang.native}
                color={lang.color}
                isSelected={selectedLang === lang.id}
                onClick={() => setSelectedLang(lang.id)}
              />
            </motion.div>
          ))}
        </div>

        <div className="flex justify-center pt-6">
          <button
            onClick={handleContinue}
            disabled={!selectedLang}
            className={`
              group relative flex items-center gap-3 px-8 py-4 rounded-2xl font-bold text-lg
              transition-all duration-300
              ${selectedLang 
                ? 'bg-primary text-white shadow-xl shadow-primary/30 hover:-translate-y-1 hover:shadow-2xl hover:shadow-primary/40' 
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'}
            `}
          >
            <span>Continue to Question</span>
            <ArrowRight className={`w-5 h-5 transition-transform ${selectedLang ? 'group-hover:translate-x-1' : ''}`} />
          </button>
        </div>
      </motion.div>
    </Layout>
  );
}
