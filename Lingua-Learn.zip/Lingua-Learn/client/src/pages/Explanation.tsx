import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Layout } from "@/components/Layout";
import { RotateCcw, ThumbsUp, Share2, Copy } from "lucide-react";
import { type QuestionResponse } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export default function Explanation() {
  const [location, setLocation] = useLocation();
  const [data, setData] = useState<QuestionResponse | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const storedData = localStorage.getItem("lastExplanation");
    if (!storedData) {
      setLocation("/ask");
      return;
    }
    setData(JSON.parse(storedData));
  }, [setLocation]);

  const handleCopy = () => {
    if (data?.explanation) {
      navigator.clipboard.writeText(data.explanation);
      toast({ title: "Copied!", description: "Explanation copied to clipboard." });
    }
  };

  if (!data) return null;

  return (
    <Layout>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-3xl mx-auto space-y-6"
      >
        <div className="bg-white rounded-[2rem] shadow-xl shadow-slate-200/60 overflow-hidden border border-slate-100">
          {/* Header Section */}
          <div className="bg-gradient-to-r from-primary/10 to-primary/5 p-8 border-b border-primary/10">
            <div className="flex items-center gap-2 mb-3">
              <span className="bg-white/80 backdrop-blur text-primary text-xs font-bold px-3 py-1 rounded-full border border-primary/10 shadow-sm">
                Question
              </span>
              <span className="text-slate-500 text-sm font-medium">in {data.language}</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-800 leading-snug font-display">
              "{data.question}"
            </h2>
          </div>

          {/* Explanation Content */}
          <div className="p-8 md:p-10 bg-white">
            <div className="flex items-center gap-2 mb-6">
               <span className="bg-green-100 text-green-700 text-xs font-bold px-3 py-1 rounded-full">
                AI Explanation
              </span>
            </div>
            
            <div className="prose prose-lg prose-slate max-w-none">
              <p className="text-xl md:text-2xl leading-relaxed text-slate-700 font-medium whitespace-pre-wrap">
                {data.explanation}
              </p>
            </div>

            {/* Action Bar */}
            <div className="mt-10 pt-6 border-t border-slate-100 flex flex-wrap gap-3">
              <button 
                onClick={handleCopy}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-50 text-slate-600 hover:bg-slate-100 font-semibold text-sm transition-colors"
              >
                <Copy className="w-4 h-4" /> Copy
              </button>
              <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-50 text-slate-600 hover:bg-slate-100 font-semibold text-sm transition-colors">
                <ThumbsUp className="w-4 h-4" /> Helpful
              </button>
              <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-50 text-slate-600 hover:bg-slate-100 font-semibold text-sm transition-colors">
                <Share2 className="w-4 h-4" /> Share
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Navigation */}
        <div className="flex justify-center pt-4">
          <button
            onClick={() => setLocation("/ask")}
            className="
              flex items-center gap-3 px-8 py-4 rounded-xl font-bold text-lg
              bg-white text-slate-700 border-2 border-slate-200 shadow-sm
              hover:border-primary hover:text-primary hover:bg-primary/5 hover:shadow-md
              transition-all duration-300
            "
          >
            <RotateCcw className="w-5 h-5" />
            <span>Ask Another Question</span>
          </button>
        </div>
      </motion.div>
    </Layout>
  );
}
