import { useMutation } from "@tanstack/react-query";
import { api, type CreateQuestionInput, type QuestionResponse } from "@shared/routes";

export function useAskQuestion() {
  return useMutation({
    mutationFn: async (data: CreateQuestionInput) => {
      // Intentionally using fetch directly here to handle potential timeouts differently if needed,
      // but sticking to standard pattern for consistency.
      const res = await fetch(api.questions.create.path, {
        method: api.questions.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        // Try to parse error message
        try {
          const errorData = await res.json();
          throw new Error(errorData.message || "Failed to get explanation");
        } catch (e) {
          throw new Error("Something went wrong. Please try again.");
        }
      }

      const result = await res.json();
      return api.questions.create.responses[201].parse(result);
    },
  });
}
