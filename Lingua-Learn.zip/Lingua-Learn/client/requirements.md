## Packages
framer-motion | Page transitions and button interactions
lucide-react | Icons for UI elements

## Notes
API endpoints:
- POST /api/questions -> { language, question } -> returns { explanation }
- This endpoint will likely take a few seconds to process (AI generation), so loading states are critical.
