
import OpenAI from "openai";

// the integration provides the API key automatically via env vars
export const openai = new OpenAI({ 
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL
});

export async function generateExplanation(question: string, language: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are a helpful teacher. Explain the following question in simple terms for a student. " +
                   `Provide the explanation in the ${language} language. Keep it clear and concise. ` +
                   "Format the response with simple paragraphs."
        },
        { role: "user", content: question },
      ],
    });
    return response.choices[0].message.content || "Could not generate explanation.";
  } catch (error) {
    console.error("OpenAI API Error:", error);
    throw new Error("Failed to generate explanation. Please try again.");
  }
}
