export function Footer() {
  return (
    <footer className="w-full py-8 mt-auto border-t border-border/40 bg-white/50 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <p className="text-muted-foreground font-medium text-sm">
          © {new Date().getFullYear()} LinguaLearn. Democratizing Education with AI.
        </p>
      </div>
    </footer>
  );
}
