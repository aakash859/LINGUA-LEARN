import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Languages } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

const LANGUAGES = [
  { code: "Tamil", label: "Tamil", native: "தமிழ்", color: "from-orange-400 to-red-500" },
  { code: "Hindi", label: "Hindi", native: "हिन्दी", color: "from-orange-500 to-yellow-500" },
  { code: "Telugu", label: "Telugu", native: "తెలుగు", color: "from-blue-400 to-indigo-500" },
  { code: "Kannada", label: "Kannada", native: "ಕನ್ನಡ", color: "from-red-400 to-pink-500" },
  { code: "Malayalam", label: "Malayalam", native: "മലയാളം", color: "from-emerald-400 to-teal-500" },
  { code: "English", label: "English", native: "English", color: "from-violet-400 to-purple-500" },
];

export default function Home() {
  const [, setLocation] = useLocation();

  const handleSelectLanguage = (lang: string) => {
    // Store in localStorage for persistence if needed, then navigate
    localStorage.setItem("lingua_lang", lang);
    setLocation(`/ask?lang=${lang}`);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-50 via-background to-background">
      <Header />

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 pt-32 pb-16 flex flex-col items-center justify-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary font-semibold text-sm mb-6 border border-primary/20">
            <Languages className="w-4 h-4" />
            <span>Select your preferred language</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-display font-bold mb-6 leading-tight">
            Learn anything in <br/>
            <span className="text-gradient">your own language</span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
            Choose a language to get started with AI-powered explanations tailored just for you.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-5xl px-4">
          {LANGUAGES.map((lang, index) => (
            <motion.button
              key={lang.code}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              onClick={() => handleSelectLanguage(lang.code)}
              className="group relative flex flex-col items-start p-8 rounded-3xl bg-white border border-border/50 shadow-lg shadow-black/5 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 text-left overflow-hidden"
            >
              <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${lang.color} opacity-10 rounded-bl-full group-hover:scale-110 transition-transform duration-500`} />
              
              <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${lang.color} flex items-center justify-center text-white font-bold text-xl mb-6 shadow-md`}>
                {lang.native[0]}
              </div>
              
              <h3 className="text-2xl font-bold text-foreground mb-1 group-hover:text-primary transition-colors">
                {lang.native}
              </h3>
              <p className="text-muted-foreground font-medium mb-8">
                {lang.label}
              </p>
              
              <div className="mt-auto flex items-center gap-2 text-sm font-bold text-primary opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                Start Learning <ArrowRight className="w-4 h-4" />
              </div>
            </motion.button>
          ))}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
