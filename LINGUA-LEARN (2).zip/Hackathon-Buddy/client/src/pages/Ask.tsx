import { useState, useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { useCreateQuestion } from "@/hooks/use-questions";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Send, Sparkles, Loader2, Copy, Check, RotateCcw } from "lucide-react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import ReactMarkdown from "react-markdown";

export default function Ask() {
  const [, setLocation] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const lang = params.get("lang") || "English";
  
  const [question, setQuestion] = useState("");
  const [result, setResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const { mutate, isPending } = useCreateQuestion();

  // Redirect if no language selected
  useEffect(() => {
    if (!params.get("lang")) {
      setLocation("/");
    }
  }, [params, setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    mutate(
      { language: lang, question },
      {
        onSuccess: (data) => {
          setResult(data.answer);
        },
      }
    );
  };

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReset = () => {
    setResult(null);
    setQuestion("");
  };

  return (
    <div className="min-h-screen flex flex-col bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-50 via-background to-background">
      <Header />

      <main className="flex-1 w-full max-w-4xl mx-auto px-4 pt-32 pb-16 flex flex-col">
        {/* Breadcrumb / Back */}
        <button 
          onClick={() => setLocation("/")}
          className="self-start flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8 font-medium"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Languages
        </button>

        <div className="flex-1 flex flex-col relative">
          <AnimatePresence mode="wait">
            {!result ? (
              <motion.div 
                key="input"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="w-full"
              >
                <div className="mb-8">
                  <h1 className="text-3xl md:text-5xl font-display font-bold mb-4">
                    Ask in <span className="text-primary">{lang}</span>
                  </h1>
                  <p className="text-lg text-muted-foreground">
                    Ask any question about science, history, or general knowledge.
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="w-full">
                  <div className="relative group">
                    <textarea
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      placeholder={`Type your question here in ${lang} or English...`}
                      className="w-full min-h-[200px] p-6 text-lg md:text-xl rounded-3xl bg-white border-2 border-border shadow-sm placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all duration-300 resize-none"
                      disabled={isPending}
                    />
                    <div className="absolute bottom-4 right-4">
                      <span className="text-xs font-bold text-muted-foreground bg-secondary/50 px-2 py-1 rounded-md">
                        {question.length} chars
                      </span>
                    </div>
                  </div>

                  <div className="mt-6 flex justify-end">
                    <button
                      type="submit"
                      disabled={!question.trim() || isPending}
                      className="
                        flex items-center gap-3 px-8 py-4 rounded-2xl font-bold text-lg
                        bg-gradient-to-r from-primary to-indigo-600 
                        text-white shadow-lg shadow-primary/25
                        hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-1
                        disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                        transition-all duration-300
                      "
                    >
                      {isPending ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Thinking...
                        </>
                      ) : (
                        <>
                          Get Explanation <Sparkles className="w-5 h-5" />
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </motion.div>
            ) : (
              <motion.div 
                key="result"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.3 }}
                className="w-full"
              >
                <div className="glass-card rounded-3xl p-8 md:p-10 border border-border/50 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary via-accent to-purple-500" />
                  
                  <div className="flex items-start justify-between gap-4 mb-8 pb-6 border-b border-border/50">
                    <div>
                      <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-2">You asked:</h3>
                      <p className="text-xl font-medium text-foreground italic">"{question}"</p>
                    </div>
                    <button 
                      onClick={handleReset}
                      className="p-2 rounded-xl hover:bg-secondary/50 text-muted-foreground hover:text-primary transition-colors"
                      title="Ask new question"
                    >
                      <RotateCcw className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="prose prose-lg prose-indigo max-w-none mb-8">
                    <ReactMarkdown>{result}</ReactMarkdown>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4 mt-8 pt-6 border-t border-border/50">
                    <button
                      onClick={handleCopy}
                      className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
                    >
                      {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                      {copied ? "Copied!" : "Copy Answer"}
                    </button>
                    
                    <button
                      onClick={handleReset}
                      className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-semibold bg-primary text-primary-foreground shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all"
                    >
                      <Send className="w-5 h-5" />
                      Ask Another Question
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      <Footer />
    </div>
  );
}
