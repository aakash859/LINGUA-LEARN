import { useMutation } from "@tanstack/react-query";
import { api, type QuestionInput } from "@shared/routes";

export function useCreateQuestion() {
  return useMutation({
    mutationFn: async (data: QuestionInput) => {
      const res = await fetch(api.questions.create.path, {
        method: api.questions.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.questions.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        if (res.status === 500) {
          const error = api.questions.create.responses[500].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to generate explanation");
      }

      return api.questions.create.responses[201].parse(await res.json());
    },
  });
}
