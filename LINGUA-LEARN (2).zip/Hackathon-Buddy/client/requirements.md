## Packages
framer-motion | For smooth page transitions and micro-interactions
lucide-react | For beautiful icons
react-markdown | To render the AI explanation nicely

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
