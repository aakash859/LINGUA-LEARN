import { questions, type Question, type InsertQuestion } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  createQuestion(question: InsertQuestion & { answer: string }): Promise<Question>;
}

export class DatabaseStorage implements IStorage {
  async createQuestion(insertQuestion: InsertQuestion & { answer: string }): Promise<Question> {
    const [question] = await db
      .insert(questions)
      .values(insertQuestion)
      .returning();
    return question;
  }
}

export const storage = new DatabaseStorage();
